package com.example.unogroupproject;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.*;


public class UnoController implements Initializable {
    @FXML
    private Text playerCardCount;

    @FXML
    private Text errorOut;

    @FXML
    private void onUnoButtonClick() {

    }

    @FXML
    private void onRedButtonClick() {
        colorSelect = "Red";
    }

    @FXML
    private void onBlueButtonClick() {
        colorSelect = "Blue";
    }

    @FXML
    private void onGreenButtonClick() {
        colorSelect = "Green";
    }

    @FXML
    private void onYellowButtonClick() {
        colorSelect = "Yellow";
    }

    @FXML
    private void onGetHelpClick() {
    }

    @FXML
    private void onQuitClick() {
        System.exit(0);
    }

    @FXML
    private void onDrawButtonClick() {
        playerHand.add(deck.drawCard());
        updateScene();
    }

    @FXML
    private FlowPane playerHandPane;

    @FXML
    private Text cpuCardCount;

    @FXML
    private ImageView deckCardViewer;

    private initDeck deck;
    private List<Player> playerList = new ArrayList<>();
    private int playerCounter;
    private String colorSelect = null;

    private List<Card> playerHand;
    private List<Card> cpuHand;
    private List<Card> discard = new ArrayList<>();

    private Card currentTopDiscard;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        deck = new initDeck();
        deck.shuffle();

        discard.add(deck.drawCard());

        playerList.add(new Player("user"));
        playerList.add(new Player("cpu"));

        for (Player player : playerList) {
            for (int i = 0; i < 7; i++) {
                player.addCard(deck.drawCard());
            }
        }

        playerHand = playerList.get(0).getHand();
        cpuHand = playerList.get(1).getHand();

        playerCounter = 0;

        playPlayer();
    }

    private void updateDiscard() {
        currentTopDiscard = discard.get(discard.size() - 1);

        deckCardViewer.setImage(currentTopDiscard.getImageLink());
    }

    @FXML
    private Text t;

    private void updateScene() {
        // Initialize any necessary components or data structures
        // https://stackoverflow.com/questions/40495658/javafx-how-make-a-clickable-image-using-scenebuilder - click
        // https://docs.oracle.com/javase/8/javafx/api/javafx/scene/layout/FlowPane.html - getchildren
        updateDiscard();
        playerCardCount.setText("Player Card Count: " + playerHand.size());
        cpuCardCount.setText("CPU Card Count: " + cpuHand.size());
        playerHandPane.getChildren().clear();
        t.setText(colorSelect);
        for (Card card : playerHand) {
            ImageView cardView = new ImageView(card.getImageLink());
            cardView.setOnMouseClicked(mouseEvent -> {
                playPlayerClickEvent(card);
            });
            cardView.setFitHeight(100);
            cardView.setFitWidth(75);
            playerHandPane.getChildren().add(cardView);
        }
    }

    private void playPlayer() {
//        playerHandPane.getChildren().clear();
//        for (Card card : playerHand) {
//            ImageView cardView = new ImageView(card.getImageLink());
//            cardView.setOnMouseClicked(mouseEvent -> { playPlayerClickEvent(card);});
//            cardView.setFitHeight(100);
//            cardView.setFitWidth(75);
//            playerHandPane.getChildren().add(cardView);
//        }
        updateScene();
    }

    private boolean playOnColorSelect(Card card) {
        return card.getCardColor() == colorSelect;
    }

    private void playPlayerHelper(Card card) {
        if (card.canBePlayedOn(currentTopDiscard)) {
            discard.add(card);
            playerHand.remove(card);
            errorOut.setText("");

            if (playerHand.isEmpty()) {
                errorOut.setText("You won!");
                return;
            }

            if (card.isPlusFour()) {
                for (int i = 0; i < 4; i++) {
                    cpuHand.add(deck.drawCard());
                }
                playerCounter++;
            } else if (card.isSkip()) {
                playerCounter++;
            } else if (card.isPlusTwo()) {
                for (int i = 0; i < 2; i++) {
                    cpuHand.add(deck.drawCard());
                }
                playerCounter++;
            }
            playerCounter++;
            updateScene();
            errorOut.setText("CPU taking turn");
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    playCPU();
                }
            }, 2000);
        }
    }

    private void waitThree() {
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void playPlayerClickEvent(Card card) {
        if (card.isWild()) {
            errorOut.setText("Select the color from the wild card selector");
        }
        if (card.canBePlayedOn(currentTopDiscard)) {
            playPlayerHelper(card);
        } else if (playOnColorSelect(card)) {
            playPlayerHelper(card);
            colorSelect = null;
        } else {
            errorOut.setText("Pick a card that's the same color, number or a wild to play on discard!");
        }
//        waitThree();
    }

    private void playCPU() {
        for (Card card : cpuHand) {
            playCPUHelper(card);
        }
//        t.setText(playerList.get(1).getHand().toString());
        updateScene();
    }

    private void playCPUHelper(Card card) {
        if (card.canBePlayedOn(currentTopDiscard)) {
            discard.add(card);
            cpuHand.remove(card);
            errorOut.setText("");

            updateDiscard();

            if (card.isWild()) {
                String[] colors = {"Red", "Green", "Blue", "Yellow"};
                colorSelect = colors[(int) (Math.random() * colors.length)];
                errorOut.setText("Bot chose: " + colorSelect);
                if (card.isPlusFour()) {
                    for (int i = 0; i < 4; i++) {
                        playerHand.add(deck.drawCard());
                    }
                    playerCounter++;
                }
            } else if (card.isSkip()) {
                playerCounter++;
            } else if (card.isPlusTwo()) {
                for (int i = 0; i < 2; i++) {
                    playerHand.add(deck.drawCard());
                }
                playerCounter++;
            }
            playerCounter++;
        } else if (playOnColorSelect(card)) {
            playCPUHelper(card);
            colorSelect = null;
        } else {
            errorOut.setText("Pick a card that's the same color, number or a wild to play on discard!");
        }
        updateScene();
    }
}